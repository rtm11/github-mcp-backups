const express = require('express');
const { Octokit } = require('@octokit/rest');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const winston = require('winston');

// Configure logging
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'github-mcp.log' })
  ]
});

const app = express();
const port = process.env.PORT || 3000;

// Initialize Octokit
const octokit = new Octokit({
  auth: process.env.GITHUB_TOKEN
});

// Middleware
app.use(helmet());
app.use(compression());
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Error handling middleware
const errorHandler = (err, req, res, next) => {
  logger.error('GitHub MCP Error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
};

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    service: 'GitHub MCP Server',
    timestamp: new Date().toISOString(),
    github_configured: !!process.env.GITHUB_TOKEN
  });
});

// List repositories
app.get('/repos', async (req, res) => {
  try {
    const { data } = await octokit.rest.repos.listForAuthenticatedUser({
      sort: 'updated',
      per_page: 100
    });
    
    const repos = data.map(repo => ({
      id: repo.id,
      name: repo.name,
      full_name: repo.full_name,
      description: repo.description,
      private: repo.private,
      html_url: repo.html_url,
      clone_url: repo.clone_url,
      updated_at: repo.updated_at,
      language: repo.language,
      stargazers_count: repo.stargazers_count
    }));
    
    res.json({ repos, count: repos.length });
  } catch (error) {
    logger.error('Error listing repositories:', error);
    res.status(500).json({ error: 'Failed to fetch repositories' });
  }
});

// Get repository content
app.get('/repos/:owner/:repo/contents/*', async (req, res) => {
  try {
    const { owner, repo } = req.params;
    const path = req.params[0] || '';
    
    const { data } = await octokit.rest.repos.getContent({
      owner,
      repo,
      path
    });
    
    res.json(data);
  } catch (error) {
    logger.error('Error getting repository content:', error);
    res.status(404).json({ error: 'Content not found' });
  }
});

// Create or update file
app.put('/repos/:owner/:repo/contents/*', async (req, res) => {
  try {
    const { owner, repo } = req.params;
    const path = req.params[0];
    const { content, message, sha } = req.body;
    
    if (!content || !message) {
      return res.status(400).json({ error: 'Content and commit message are required' });
    }
    
    const params = {
      owner,
      repo,
      path,
      message,
      content: Buffer.from(content).toString('base64')
    };
    
    if (sha) {
      params.sha = sha;
    }
    
    const { data } = await octokit.rest.repos.createOrUpdateFileContents(params);
    res.json(data);
  } catch (error) {
    logger.error('Error creating/updating file:', error);
    res.status(500).json({ error: 'Failed to create/update file' });
  }
});

// Search repositories
app.get('/search/repositories', async (req, res) => {
  try {
    const { q, sort = 'updated', order = 'desc', per_page = 30 } = req.query;
    
    if (!q) {
      return res.status(400).json({ error: 'Query parameter "q" is required' });
    }
    
    const { data } = await octokit.rest.search.repos({
      q,
      sort,
      order,
      per_page
    });
    
    res.json({
      total_count: data.total_count,
      items: data.items.map(repo => ({
        id: repo.id,
        name: repo.name,
        full_name: repo.full_name,
        description: repo.description,
        html_url: repo.html_url,
        language: repo.language,
        stargazers_count: repo.stargazers_count,
        updated_at: repo.updated_at
      }))
    });
  } catch (error) {
    logger.error('Error searching repositories:', error);
    res.status(500).json({ error: 'Search failed' });
  }
});

// Get repository issues
app.get('/repos/:owner/:repo/issues', async (req, res) => {
  try {
    const { owner, repo } = req.params;
    const { state = 'open', per_page = 30 } = req.query;
    
    const { data } = await octokit.rest.issues.listForRepo({
      owner,
      repo,
      state,
      per_page
    });
    
    res.json(data);
  } catch (error) {
    logger.error('Error getting issues:', error);
    res.status(500).json({ error: 'Failed to fetch issues' });
  }
});

// Create issue
app.post('/repos/:owner/:repo/issues', async (req, res) => {
  try {
    const { owner, repo } = req.params;
    const { title, body, labels, assignees } = req.body;
    
    if (!title) {
      return res.status(400).json({ error: 'Title is required' });
    }
    
    const { data } = await octokit.rest.issues.create({
      owner,
      repo,
      title,
      body,
      labels,
      assignees
    });
    
    res.json(data);
  } catch (error) {
    logger.error('Error creating issue:', error);
    res.status(500).json({ error: 'Failed to create issue' });
  }
});

// Get pull requests
app.get('/repos/:owner/:repo/pulls', async (req, res) => {
  try {
    const { owner, repo } = req.params;
    const { state = 'open', per_page = 30 } = req.query;
    
    const { data } = await octokit.rest.pulls.list({
      owner,
      repo,
      state,
      per_page
    });
    
    res.json(data);
  } catch (error) {
    logger.error('Error getting pull requests:', error);
    res.status(500).json({ error: 'Failed to fetch pull requests' });
  }
});

// MCP Protocol implementation
app.post('/mcp/tools/call', async (req, res) => {
  try {
    const { name, arguments: args } = req.body;
    
    let result;
    
    switch (name) {
      case 'list_repositories':
        const repos = await octokit.rest.repos.listForAuthenticatedUser();
        result = { repositories: repos.data };
        break;
        
      case 'get_repository_content':
        const content = await octokit.rest.repos.getContent({
          owner: args.owner,
          repo: args.repo,
          path: args.path || ''
        });
        result = { content: content.data };
        break;
        
      case 'search_repositories':
        const search = await octokit.rest.search.repos({
          q: args.query,
          sort: args.sort || 'updated',
          order: args.order || 'desc'
        });
        result = { search_results: search.data };
        break;
        
      default:
        return res.status(400).json({ error: `Unknown tool: ${name}` });
    }
    
    res.json({ result });
  } catch (error) {
    logger.error('MCP tool call error:', error);
    res.status(500).json({ error: 'Tool execution failed' });
  }
});

// Get available tools
app.get('/mcp/tools', (req, res) => {
  const tools = [
    {
      name: 'list_repositories',
      description: 'List all repositories for the authenticated user',
      inputSchema: {
        type: 'object',
        properties: {}
      }
    },
    {
      name: 'get_repository_content',
      description: 'Get contents of a repository file or directory',
      inputSchema: {
        type: 'object',
        properties: {
          owner: { type: 'string', description: 'Repository owner' },
          repo: { type: 'string', description: 'Repository name' },
          path: { type: 'string', description: 'File or directory path' }
        },
        required: ['owner', 'repo']
      }
    },
    {
      name: 'search_repositories',
      description: 'Search for repositories on GitHub',
      inputSchema: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'Search query' },
          sort: { type: 'string', description: 'Sort order' },
          order: { type: 'string', description: 'Sort direction' }
        },
        required: ['query']
      }
    }
  ];
  
  res.json({ tools });
});

app.use(errorHandler);

app.listen(port, '0.0.0.0', () => {
  logger.info(`GitHub MCP Server running on port ${port}`);
  logger.info(`GitHub token configured: ${!!process.env.GITHUB_TOKEN}`);
});

module.exports = app;